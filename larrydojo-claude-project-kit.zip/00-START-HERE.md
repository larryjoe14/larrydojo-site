# Larrydojo.com redesign: Claude Project kit

Assembled August 25, 2026.

## Set up the Project

1. Create a Claude Project named **Larrydojo.com redesign**.
2. Open Project settings → custom instructions. Paste the contents of `PROJECT-INSTRUCTIONS.md`.
3. Upload every `.md` file in this kit as project knowledge. Upload `larrydojo-prototype.html` too; Claude can read it as text.
4. Keep `larrydojo-site.zip` on your machine or in the repo. It is the code; Claude reads the key files from `08-code-reference.md` and the README instead.
5. Start the first conversation with: "Read the launch checklist and tell me the next three things to do."

## What is in the kit

| File | What it is | Read it when |
|---|---|---|
| `PROJECT-INSTRUCTIONS.md` | Custom instructions for the Project | Setup |
| `01-research-summary.md` | Verified findings with sources; corrections to the source reports | Citing facts on the site |
| `02-site-audit.md` | Audit of the current site against four lenses, plus the redesign path | Deciding what to change |
| `03-redesign-brief.md` | Architecture, page briefs, wireframes, fan discovery, content model | Building or editing any page |
| `04-build-README.md` | Run, deploy, add an episode, fill-in list, file tree | Working in the code |
| `05-launch-checklist.md` | Done / Phase 0 / pre-launch / Phase 2 / Phase 3 with checkboxes | Every session |
| `06-copy-deck.md` | Every line of site copy by page, with the file it lives in | Editing copy |
| `07-design-tokens.md` | Palette, type, layout, signature, rules | Any visual change |
| `08-code-reference.md` | Schema, helpers, episode template, Player, Ledger, redirects, example episode, verbatim | Editing templates or content |
| `research-source-1-ai-in-entertainment-2026.md` | Your source report, figures stripped | Background only; use 01 for facts |
| `research-source-2-ai-video-tools-landscape.md` | Your source report, figures stripped | Background only; use 01 for facts |
| `larrydojo-prototype.html` | Clickable single-file prototype of all nine views | Showing the design to someone |
| `larrydojo-site.zip` | The Astro project, builds clean, 20 pages | Deploying |

## Where things stand

Audit, brief, prototype, and a building Astro project are done. The site is not deployed. Next: push to GitHub, link to Netlify, and work down `05-launch-checklist.md`. The first content jobs are the placeholder copy on Robo Noir and Cthulhu, two posters, one video ID, your photo, and the reel.

## Working agreements

- Copy follows Strunk and White and the rules in `PROJECT-INSTRUCTIONS.md`.
- Facts about Netflix, guidelines, and copyright come from `01-research-summary.md`.
- The content model is the boundary: if a change needs a new field, add it to `src/content.config.ts` and document it in the README.
- Placeholders are tagged `draft` in front matter and show a badge on the page. Remove the tag when the copy is final.
