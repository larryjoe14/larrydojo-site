# Code reference

The files future conversations will edit most, verbatim from larrydojo-site.zip. Full tree in 04-build-README.md.

## `src/content.config.ts`

```ts
import { defineCollection, reference, z } from 'astro:content';
import { glob } from 'astro/loaders';

const shows = defineCollection({
  loader: glob({ pattern: '**/*.md', base: './src/content/shows' }),
  schema: z.object({
    title: z.string(),
    status: z.string(),            // "Ongoing", "Complete", "Short film", "Four parts"
    cadence: z.string(),           // "New episodes monthly"
    logline: z.string(),
    about: z.string(),
    poster: z.string().optional(), // /media/<show>/poster.jpg (2:3)
    fiction: z.boolean().default(false), // ledger labels: "From the source / Original to the show"
    order: z.number().default(99),
    draft: z.boolean().default(false),
  }),
});

const episodes = defineCollection({
  loader: glob({ pattern: '**/*.md', base: './src/content/episodes' }),
  schema: z.object({
    show: reference('shows'),
    episode: z.number(),
    title: z.string(),
    synopsis: z.string(),
    youtubeId: z.string().optional(),
    runtime: z.string().optional(),
    released: z.union([z.string(), z.date()]).transform(v => v instanceof Date ? v.toISOString().slice(0, 10) : String(v)), // YYYY-MM-DD, or YYYY-MM while in production
    status: z.enum(['published', 'production']).default('published'),
    ledgerReal: z.array(z.string()).default([]),
    ledgerBuilt: z.array(z.string()).default([]),
    lesson: z.string().optional(),
    frames: z.array(z.string()).optional(), // [plate, composite, motion] image paths
    sources: z.array(z.object({ title: z.string(), url: z.string() })).default([]),
    tags: z.array(z.union([z.string(), z.number()]).transform(String)).default([]),
    spec: z.string().optional(),   // "4K · 24fps · 2:40 · 3 days"
    featuredInWork: z.boolean().default(false),
    workOrder: z.number().default(99),
    draft: z.boolean().default(false),
  }),
});

export const collections = { shows, episodes };
```

## `src/lib/site.ts`

```ts
import { getCollection, type CollectionEntry } from 'astro:content';

export type Ep = CollectionEntry<'episodes'>;
export type Show = CollectionEntry<'shows'>;

export const STEPS = [
  ['1', 'Character built once', 'A bible and a three-view pack, validated before anything else starts.'],
  ['2', 'Plates built empty', 'Rooms and streets as reusable kits, never finished scenes.'],
  ['3', 'Anchor, then composite', 'Never generate a character inside a scene. Place the anchor into the plate.'],
  ['4', 'Last frame feeds the next', 'Dust, light, and prop positions carry across the cut.'],
  ['5', 'Edit, never re-roll', 'A frame that is 80% right gets a natural-language fix, not a fresh draw.'],
];

export const SITE = {
  name: 'Larrydojo',
  email: 'hello@larrydojo.com',
  city: 'Atlanta, GA',
  youtube: 'https://www.youtube.com/@larrydojo',
  tiktok: 'https://www.tiktok.com/@larrydojo_noir',
  instagram: 'https://www.instagram.com/larrydojo/',
  linkedin: 'https://www.linkedin.com/',   // add the profile URL
};

export const showSlug = (e: Ep) => e.id.split('/')[0];
export const epSlug = (e: Ep) => e.id.split('/').slice(1).join('/');
export const epHref = (e: Ep) => `/shows/${showSlug(e)}/${epSlug(e)}/`;
export const showHref = (s: Show) => `/shows/${s.id}/`;
export const thumb = (e: Ep) => e.data.youtubeId ? `https://i.ytimg.com/vi/${e.data.youtubeId}/hqdefault.jpg` : null;
export const published = (e: Ep) => e.data.status === 'published';

export function fmtDate(d: string) {
  return d.length === 7
    ? new Date(d + '-01T12:00:00').toLocaleString('en-US', { month: 'short', year: 'numeric' })
    : new Date(d + 'T12:00:00').toLocaleString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

export async function allShows() {
  return (await getCollection('shows')).sort((a, b) => a.data.order - b.data.order);
}
export async function episodesOf(showId: string) {
  return (await getCollection('episodes', e => e.data.show.id === showId)).sort((a, b) => a.data.episode - b.data.episode);
}
export async function latestEpisode() {
  return (await getCollection('episodes', published)).sort((a, b) => b.data.released.localeCompare(a.data.released))[0];
}
export async function workItems() {
  return (await getCollection('episodes', e => e.data.featuredInWork && published(e))).sort((a, b) => a.data.workOrder - b.data.workOrder);
}
```

## `src/pages/shows/[show]/[ep].astro`

```astro
---
import Base from '../../../layouts/Base.astro';
import Player from '../../../components/Player.astro';
import Ledger from '../../../components/Ledger.astro';
import Frames from '../../../components/Frames.astro';
import { getCollection, getEntry, render } from 'astro:content';
import { SITE, episodesOf, epHref, epSlug, showSlug, showHref, thumb, fmtDate } from '../../../lib/site';
export async function getStaticPaths() {
  const eps = await getCollection('episodes', e => e.data.status === 'published');
  return eps.map(ep => ({ params: { show: showSlug(ep), ep: epSlug(ep) }, props: { ep } }));
}
const { ep } = Astro.props;
const show = (await getEntry(ep.data.show))!;
const all = await episodesOf(show.id);
const i = all.findIndex(e => e.id === ep.id);
const prev = all[i - 1];
const next = all[i + 1];
const nextSoon = next && next.data.status !== 'published';
const { Content } = await render(ep);
const hasTranscript = ep.body && ep.body.trim().length > 0;
const single = show.data.status === 'Short film';
const title = single ? `${show.data.title} | Larrydojo` : `${show.data.title} Ep. ${ep.data.episode}: ${ep.data.title} | Larrydojo`;
const image = thumb(ep) ?? show.data.poster;
const url = new URL(epHref(ep), Astro.site).toString();
const jsonld = {
  '@context': 'https://schema.org',
  '@graph': [
    { '@type': 'TVEpisode', name: ep.data.title, episodeNumber: ep.data.episode, description: ep.data.synopsis, url,
      datePublished: ep.data.released, partOfSeries: { '@type': 'TVSeries', name: show.data.title, url: new URL(showHref(show), Astro.site).toString() },
      ...(image ? { image } : {}), productionCompany: { '@type': 'Organization', name: 'Larrydojo LLC' } },
    ...(ep.data.youtubeId ? [{ '@type': 'VideoObject', name: `${show.data.title}: ${ep.data.title}`, description: ep.data.synopsis,
      thumbnailUrl: image, uploadDate: ep.data.released, embedUrl: `https://www.youtube.com/embed/${ep.data.youtubeId}`,
      contentUrl: `https://www.youtube.com/watch?v=${ep.data.youtubeId}`, ...(ep.data.runtime ? { duration: `PT${ep.data.runtime.replace(':', 'M')}S` } : {}) }] : []),
  ],
};
---
<Base title={title} description={ep.data.synopsis} nav="shows" jsonld={jsonld} image={image} type="video.other">
  <article data-pagefind-body data-pagefind-meta={`show:${show.data.title}`}>
  <section class="first" style="padding-top:28px">
    <div class="wrap">
      <div class="status"><a href={showHref(show)} style="text-decoration:none">{show.data.title}</a> · Episode {ep.data.episode}{ep.data.runtime && ` · ${ep.data.runtime}`} · {fmtDate(ep.data.released)}</div>
      <h1 style="margin:8px 0 18px;font-size:clamp(30px,4.6vw,56px)">{ep.data.title}{ep.data.draft && <> <span class="badge note">draft</span></>}</h1>
      <Player youtubeId={ep.data.youtubeId} alt={`${show.data.title}: ${ep.data.title}`} />
      <div class="pn">
        <a href={prev ? epHref(prev) : '#'} class={prev ? '' : 'off'}>← {prev ? `Episode ${prev.data.episode}` : 'First episode'}</a>
        <a href={next && !nextSoon ? epHref(next) : showHref(show)} class="next">{next ? (nextSoon ? 'Next episode in production' : `Next: Episode ${next.data.episode}`) : 'All episodes'} →</a>
      </div>
      <p style="max-width:720px;margin-top:22px;font-size:18px">{ep.data.synopsis}</p>
      {ep.data.spec && <div class="spec" data-pagefind-ignore>{ep.data.spec}</div>}
      {ep.data.tags.length > 0 && <div class="row" style="margin-top:12px;gap:8px">{ep.data.tags.map(t => <a class="badge" href={`/search/?q=${encodeURIComponent(t)}`} data-pagefind-filter="tag">{t}</a>)}</div>}
    </div>
  </section>

  <div class="paper" style="margin-top:56px" id="record">
    <section class="first" style="padding-top:64px">
      <div class="wrap">
        <div class="eyebrow">The record</div>
        <h2 style="max-width:760px">{show.data.fiction ? 'From the source. Original to the show.' : 'What is documented. What is built.'}</h2>
        <div style="height:28px"></div>
        <Ledger real={ep.data.ledgerReal} built={ep.data.ledgerBuilt} fiction={show.data.fiction} />
      </div>
    </section>
    <section>
      <div class="wrap">
        <div class="eyebrow">How it was made</div>
        <Frames frames={ep.data.frames} />
        {ep.data.lesson && <p style="max-width:720px;margin-top:22px;font-size:18px">{ep.data.lesson}</p>}
        <a class="btn quiet" href="/method/">The full method</a>
      </div>
    </section>
    {ep.data.sources.length > 0 && (
      <section><div class="wrap">
        <div class="eyebrow">Sources and deeper reading</div>
        {ep.data.sources.map(s => <p><a href={s.url} target="_blank" rel="noopener">{s.title} ↗</a></p>)}
      </div></section>
    )}
    <section>
      <div class="wrap">
        {hasTranscript && <details><summary>Transcript</summary><div class="prose transcript" style="margin-top:12px"><Content /></div></details>}
        <details><summary>Credits</summary><p style="margin-top:12px">Written, directed, and produced by Alec Young. Made with AI; disclosed in the title. Sources listed above.</p></details>
      </div>
    </section>
    <section>
      <div class="wrap">
        <div class="eyebrow">Up next</div>
        {next && !nextSoon ? (
          <a class="nextcard" href={epHref(next)}>
            <div class="thumb">{thumb(next) && <img loading="lazy" src={thumb(next)} alt="">}</div>
            <div><div class="status">Next · Episode {next.data.episode}</div><h3 style="margin:6px 0">{next.data.title}</h3><p class="muted" style="margin:0">{next.data.synopsis}</p></div>
          </a>
        ) : next ? (
          <div class="nextcard"><div></div><div><div class="status">Next · Episode {next.data.episode}</div><h3 style="margin:6px 0">In production</h3><p class="muted" style="margin:0">One message when it lands: <a href={`${showHref(show)}rss.xml`}>RSS</a>.</p></div></div>
        ) : (
          <div class="nextcard"><div></div><div><div class="status">Complete</div><h3 style="margin:6px 0">That is the whole film.</h3><p class="muted" style="margin:0"><a href="/shows/">More shows</a></p></div></div>
        )}
        <div class="row" style="margin-top:20px;gap:18px"><a href={showHref(show)}>All episodes</a><a href={SITE.youtube}>YouTube</a><a href={`${showHref(show)}rss.xml`}>RSS</a></div>
      </div>
    </section>
    <section>
      <div class="wrap row" style="justify-content:space-between">
        <span class="muted">Larrydojo builds video like this for productions.</span>
        <a class="btn" href="/work/">See the work</a>
      </div>
    </section>
  </div>
  </article>
  <script define:vars={{ showId: show.id, n: ep.data.episode, title: ep.data.title, href: epHref(ep) }}>
    try { localStorage.setItem('ld:last:' + showId, JSON.stringify({ n, title, href })); } catch {}
  </script>
</Base>
```

## `src/components/Player.astro`

```astro
---
interface Props { youtubeId?: string; alt: string; label?: string; }
const { youtubeId, alt, label } = Astro.props;
---
{youtubeId ? (
  <div class="player" data-yt={youtubeId}>
    <img src={`https://i.ytimg.com/vi/${youtubeId}/maxresdefault.jpg`} alt={alt} loading="eager" fetchpriority="high"
         onerror={`this.onerror=null;this.src='https://i.ytimg.com/vi/${youtubeId}/hqdefault.jpg'`}>
    {label && <span class="tag badge">{label}</span>}
    <button class="play" type="button" aria-label={`Play: ${alt}`}></button>
  </div>
) : (
  <div class="player empty"><span class="mono muted">Video to add</span></div>
)}
```

## `src/components/Ledger.astro`

```astro
---
import { marked } from '../lib/marked';
interface Props { real: string[]; built: string[]; fiction?: boolean; }
const { real, built, fiction = false } = Astro.props;
const [lh, rh] = fiction ? ['From the source', 'Original to the show'] : ['What is documented', 'What is built'];
---
<div class="ledger">
  <div class="real"><h3>{lh}</h3><ul>{real.map(x => <li set:html={marked(x)} />)}</ul></div>
  <div class="built"><h3>{rh}</h3><ul>{built.map(x => <li set:html={marked(x)} />)}</ul></div>
</div>
```

## `netlify.toml`

```toml
[build]
  command = "npm run build"
  publish = "dist"

[[headers]]
  for = "/*"
  [headers.values]
    X-Content-Type-Options = "nosniff"
    Referrer-Policy = "strict-origin-when-cross-origin"
```

## `public/_redirects`

```text
# Old URLs keep working after the redesign
/1863-a-gold-rush-story/            /shows/1863/the-film/              301
/1863-a-gold-rush-story             /shows/1863/the-film/              301
/case-studies/dick-tracy-origins/   /shows/hawknose/origins/           301
/case-studies/dick-tracy-origins    /shows/hawknose/origins/           301
/case-studies/robot-that-can-think/ /shows/robot-that-can-think/       301
/the-dreams-of-cthulhu/             /shows/dreams-of-cthulhu/          301
```

## Example episode file: `src/content/episodes/1863/the-film.md`

```markdown
---
show: 1863
episode: 1
title: A Gold Rush Story
synopsis: Oroville, California, May 1863. The easy gold is a decade gone and the wagon traffic runs the other way, toward Idaho. An old minister works his week anyway. At the end of it, a newspaper on the ground.
youtubeId: NNRUGBYN6BA
runtime: "2:40"
released: 2026-05-16
ledgerReal:
  - "**The clipping.** Weekly Butte Record, Oroville, May 16, 1863, page 4."
  - Publisher George H. Crossette.
  - Earliest known "smart aleck" in print; origin of the phrase unknown. The OED declines to name a source.
  - The pruning proverb.
  - "1863 mining reality: surface gold exhausted by the mid-1850s, hydraulic and quartz operations working men for wages."
  - 1863 migration ran toward the Boise mines, not into California.
  - The Chinese Temple, dedicated in Oroville that same spring.
  - "The shape of a minister's week: parsonage, salary partly in goods, two original sermons every Sunday, no pension."
ledgerBuilt:
  - "**The minister.** Face, age, widowhood, all of it."
  - Whether the article is about him. The film leaves it open; history is silent.
  - Who wrote the item. Small weeklies signed nothing; never asserted.
  - "**Every image in the film.** No photograph of 1863 Oroville street life exists."
lesson: The newspaper was never generated. The headline in the film is the Library of Congress scan of the real page, composited in.
frames:
  - https://larrydojo.com/1863-a-gold-rush-story/img/street-plate.jpg
  - https://larrydojo.com/1863-a-gold-rush-story/img/street-final.jpg
  - https://larrydojo.com/1863-a-gold-rush-story/img/street-poster.jpg
sources:
  - title: Weekly Butte Record, May 16, 1863, p. 4 · Library of Congress, Chronicling America
    url: https://chroniclingamerica.loc.gov/lccn/sn86058108/1863-05-16/ed-1/seq-4/
  - title: "Etymonline · Green's Dictionary of Slang: smart aleck"
    url: https://www.etymonline.com/word/smart%20aleck
  - title: Dave Wilton, wordorigins.org, on the Aleck Hoag theory
    url: https://www.wordorigins.org/big-list-entries/smart-aleck
  - title: Viral Texts Project, Northeastern University
    url: https://viraltexts.org/
  - title: Oroville Chinese Temple, National Historic Landmark
    url: https://en.wikipedia.org/wiki/Chinese_Temple_(Oroville,_California)
tags: [1863, gold-rush, recreation, primary-source]
spec: 4K · 24fps · 2:40 · 1 primary source · 3 days
featuredInWork: true
workOrder: 0
---
"SMART ALECK" IN THE PULPIT.

A story is told of an old minister, who once announced to his hearers that on a following Sabbath he would tell his people what time to trim apple trees. The announcement had the desired effect, drawing out a large congregation. At the close of the service he announced that the time for his hearers to trim apple trees was when their tools were sharp.

*Weekly Butte Record, Oroville, Cal., May 16, 1863, p. 4.*
```
