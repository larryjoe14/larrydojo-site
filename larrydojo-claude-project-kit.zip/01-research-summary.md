# Research summary, verified

**Checked:** August 25, 2026. Two source reports supplied by Alec (research-source-1 and -2) were read and their load-bearing claims verified against primary sources. Use this file, not the source reports, when citing facts on the site.

## Confirmed

### Netflix, roughly 300 titles
The Q2 2026 shareholder letter (July 16, 2026) states that GenAI tools were used on about 300 titles this year, with the largest concentration in post-production, and that use spans concept, pre-visualization, production, and delivery. Netflix says some productions would have left out key shots and sequences without it. Named examples: *Glory* (India), *Brasil 70: A Saga do Tri* (Brazil), *The American Experiment* (U.S.), which used AI for crowd enhancement, historical battle sequences, and establishing shots.
Financials that quarter: $12.56B revenue, $0.80 EPS, 33% operating margin. Shares fell about 8% after hours on a revenue miss.
Sources: Netflix Q2 2026 Shareholder Letter, s22.q4cdn.com/959853165/files/doc_financials/2026/q2/FINAL-Q2-26-Shareholder-Letter.pdf; Variety, July 16, 2026.

### InterPositive
Acquired by Netflix in March 2026 for about $600 million. Co-founded by Ben Affleck. Tools operate on existing footage (relighting, VFX modification, editing automation), not text-to-video. Netflix also runs Eyeline (VFX research) and an AI animation lab (INKubator).

### Netflix partner guidelines for GenAI
Published August 2025 on the Netflix Partner Help Center, still in force. Key requirements a vendor must meet:
- Disclose intended GenAI use to the Netflix production contact.
- Written approval before output appears in a final deliverable, or touches talent likeness, personal data, or third-party IP.
- Tools run in enterprise-secured environments that do not train on, reuse, or store production inputs and outputs.
- No recreation of copyrighted material or unowned likeness. No content that could be mistaken for real events, people, or statements that never occurred.
- No replacement of union-covered work (actors, writers, crew) without proper approvals or agreements.
- Custom multi-tool pipelines must meet the standard at every step. Production partners hiring a vendor should use the guidance to assess how the vendor manages data, creative control, and final outputs.
- Low-risk uses that follow the principles are unlikely to need legal review beyond disclosure.
Source: partnerhelp.netflixstudios.com/hc/en-us/articles/43393929218323-Using-Generative-AI-in-Content-Production.

### Human authorship and copyright
Supreme Court denied certiorari in *Thaler v. Perlmutter* (No. 25-449) on March 2, 2026, leaving the D.C. Circuit's 2025 ruling intact: copyright requires human authorship. Purely AI-generated work is not registrable. Hybrid work with meaningful human authorship is, with AI-generated portions disclaimed in the application. Detailed prompting alone is not sufficient authorship under the Copyright Office's Part 2 report (January 2025).
Sources: SCOTUSblog, Thaler v. Perlmutter; U.S. Copyright Office, copyright.gov/ai.

### Lionsgate and Runway, Disney and OpenAI
Both source reports describe an expanded Lionsgate–Runway partnership (equity stake, custom model on Lionsgate's library, June 2026) and a Disney–OpenAI Sora licensing deal ($1B investment, December 2025). These are consistent with public reporting and are useful context, but the site does not need to cite them.

## Corrected

### "Recre"
Source report 1 claims "Recre" is established industry shorthand for re-creation footage. Its citations for that section are a film-museum monograph and two law review articles, not trade publications. The standard terms are **recreations** (or re-creations), **reenactments**, and **historical reconstruction**. "Re-cre" exists as crew slang in unscripted and true-crime rooms. Use the full word on the site.

### Site's own legal FAQ
The current larrydojo.com FAQ stops at the May 2025 D.C. Circuit decision. Update to the March 2, 2026 cert denial.

## Directional, from August 2026 roundups

Lower-quality sources; treat as trend, not fact.
- The market has moved from impressive single clips to controllable, repeatable production. Differentiators now: character consistency past 60 seconds, multi-shot continuity, native audio (becoming table stakes), machine-readable provenance.
- Provenance marking became mandatory for EU distribution on August 2, 2026.
- Sora has lost product momentum; Google is distributing Veo across its surfaces; Seedance and Kling are gaining; ByteDance signed MPA copyright-protection agreements in August after the Seedance 2.0 controversy.
- Per-second API pricing is falling fastest at the budget tier and has not stayed stable for a full quarter in 2026.

## What this means for the site

1. Market the method, governance, and handoff. Tool names date within a quarter.
2. The buyer's risk lives in review and audit. The ledger, log, source list, and provenance manifest are the product.
3. "Shots you would otherwise cut" is Netflix's own frame. Use it.
4. An archival-source recreation (the kind *The American Experiment* used) is the portfolio piece that sits closest to what buyers are purchasing. Public-domain comics prove consistency; archival recreation proves the job.
