# Launch checklist

Status as of August 25, 2026. Update this file as items close.

## Done

- [x] Site audit against the four lenses (02-site-audit.md)
- [x] Redesign brief with page briefs, architecture, content model (03-redesign-brief.md)
- [x] Clickable prototype, nine views (larrydojo-prototype.html)
- [x] Astro project: content collections, two-layer episode template, series and hub pages, Work, Method with compliance table, About, Contact (Netlify Forms), search (Pagefind), RSS per show and all shows, sitemap, structured data, redirects (larrydojo-site.zip)
- [x] Build verified: 20 pages, 6 feeds, Pagefind index of 6 episode pages

## Phase 0: fixes to the live site this week (no redesign needed)

- [ ] Put real numbers in the stats HTML; the counters render 0% without JavaScript
- [ ] Update the legal FAQ to the March 2, 2026 cert denial
- [ ] Add name, photo, one paragraph, Atlanta, and LinkedIn to the About anchor
- [ ] Add a plain-text email address to the contact section
- [ ] Hide the honeypot with aria-hidden and tabindex, not CSS alone
- [ ] Remove the duplicate Dick Tracy card
- [ ] Rename or retire the files named `img-concept-megaman.jpg` and `img-char-megaman.jpg`
- [ ] Turn off autoplay on all but the hero video
- [ ] Pick one spelling: Larrydojo

## Before the new site goes live

- [ ] Push the project to GitHub; link to Netlify; confirm the first deploy builds
- [ ] `src/lib/site.ts`: LinkedIn URL
- [ ] `src/pages/index.astro`: `REEL_ID` once the reel is cut
- [ ] `src/pages/contact.astro`: `SCHEDULER_URL` (Cal.com or Calendly)
- [ ] Netlify → Forms: enable notifications for the `brief` form
- [ ] `public/media/alec.jpg`; replace the photo placeholders in `index.astro` and `about.astro`
- [ ] Posters (2:3) for Robot That Can Think and The Dreams of Cthulhu; upgrade Robo Noir's to a true poster
- [ ] `youtubeId` for Robot That Can Think, Part 1
- [ ] Replace placeholder copy on Robo Noir and Cthulhu (synopses, ledgers, transcripts); remove `draft: true`
- [ ] Move images from the live site into `public/media/` and update paths
- [ ] Add full transcripts as episode bodies
- [ ] Decide on Robo Jr.: original character (rename files) or derived from Mega Man (retire)
- [ ] Confirm `public/_redirects` covers every URL that has been shared
- [ ] Set the Netlify site's custom domain and let the old site go
- [ ] Run Lighthouse on mobile; target performance above 85, LCP under 2.5s

## Phase 2: assets that close the gap (weeks 4 to 8)

- [ ] The reel: 60 to 90 seconds, 4K, opens on the best recreation shot, shows plate/composite/motion once, ends on a card with name and email
- [ ] Deliverables sample: a downloadable folder from one project (bible, plates, log, sources, ledger, manifest)
- [ ] One archival-source recreation, 2 to 3 minutes, with a full ledger, aimed at documentary buyers. Candidates: the Gabriel's Rebellion research, the Kansas ephemera archive
- [ ] Update the Hawknose case study to the new template and cost frame; ungate the summary, gate the full framework by email
- [ ] Ephemera show: one-minute pieces as a sixth show, tagged by era

## Phase 3: distribution

- [ ] LinkedIn profile rewritten to match the site; post each project's ledger as a carousel
- [ ] Direct outreach to Atlanta documentary and unscripted production companies with the reel and the compliance page
- [ ] Submit the archival recreation to the Runway AI Film Festival and one documentary festival with an AI category
- [ ] Write for a trade audience: what a streamer's GenAI guidelines ask a vendor for, from the vendor side
- [ ] Every YouTube description opens with the episode page link; playlists mirror series pages; TikTok bio points to /shows/

## Measure

Reel plays and completion; clicks from Work to How-it-was-made; calls booked per week; inbound from LinkedIn versus search; time on Method and Compliance.
