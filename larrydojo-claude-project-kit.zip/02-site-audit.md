# Larrydojo.com: Audit and Redesign Path

**Prepared for:** Alec Young, Larrydojo LLC
**Date:** August 25, 2026
**Scope:** Homepage, 1863: A Gold Rush Story, Dick Tracy Origins case study, plus verification of the two research reports supplied.

---

## The short version

The deep pages are better than the homepage. The 1863 film page and the Dick Tracy case study already contain the two things a professional buyer wants to see: an authorship ledger (what was real, what was built) and a gated, repeatable pipeline. The homepage hides both behind marketing-agency copy aimed at a different customer.

Five findings drive everything below:

1. **The site sells three businesses to two audiences, and neither is the one you want.** "AI content, rapid websites, and custom apps" talks to small-business marketing buyers. "The New Showrunner Era" talks to YouTube animators. Neither is a documentary producer, post supervisor, or showrunner with a Netflix delivery schedule.
2. **Your name is not on the homepage.** No bio, no photo, no LinkedIn, no location. The nav has an "About" link that goes to a section that does not exist. A producer cannot tell who they would be hiring.
3. **The proof is buried.** The "documented vs. constructed" ledger on the 1863 page is the strongest credibility asset on the site. It is three clicks deep and unnamed on the homepage.
4. **The cost framing works against you.** "$0.37 per second" and "$14.68" anchor you as a hobbyist. Netflix's own language is "shots that would otherwise have been cut." That is the comparison that sells.
5. **The homepage is heavy and the numbers are broken for anyone without JavaScript.** Four autoplaying YouTube embeds plus two MP4 loops, and the stats section renders "0% of Gen Z fans prefer indie YouTube series" to crawlers, screen readers, and AI assistants.

**Verdict:** A full redesign of the homepage, contact flow, and site architecture. Keep the deep pages, promote them, and add three pages that do not exist yet: About, Method & Compliance, and a Work index with a reel.

---

## 1. What the research says, checked

I read both reports and verified the load-bearing claims.

### Confirmed

- **Netflix, ~300 titles.** The Q2 2026 shareholder letter (July 16, 2026) says GenAI touched roughly 300 titles this year, concentrated in post-production, with use spanning concept, previz, production, and delivery. Named examples: *Glory* (India), *Brasil 70: A Saga do Tri* (Brazil), and *The American Experiment* (U.S.), which used AI for crowd enhancement, historical battle sequences, and establishing shots. Sources: Netflix shareholder letter; Variety, July 16, 2026.
- **InterPositive.** Netflix acquired Ben Affleck's InterPositive in March 2026 for about $600 million. Its tools work on existing footage (relighting, VFX modification) rather than text-to-video. Netflix also runs an AI animation lab (INKubator) and Eyeline, its VFX research group.
- **Netflix partner guidelines.** Published August 2025, still in force. Partners must disclose any intended GenAI use to their Netflix contact. Written approval is required when output is a final deliverable or touches talent likeness, personal data, or third-party IP. Tools must run in enterprise-secured environments that do not train on or store production inputs. GenAI may not replace union-covered work without agreement. Vendors with custom multi-tool pipelines must meet the standard at every step. Source: Netflix Partner Help Center, "Using Generative AI in Content Production."
- **Human authorship.** The Supreme Court denied certiorari in *Thaler v. Perlmutter* on March 2, 2026, leaving the D.C. Circuit ruling intact. Purely AI-generated work is uncopyrightable; hybrid work with meaningful human authorship is registrable, with the AI portions disclaimed. Your FAQ stops at the May 2025 D.C. Circuit decision and needs the update.

### Corrected

- **"Recre."** The report's claim that "Recre" is established industry shorthand for re-creation footage is the weakest-sourced section in either document. Its citations are a film-museum monograph and two law review articles, not trade publications or crew usage. The standard terms are **recreations** (or re-creations), **reenactments**, and **historical reconstruction**; "re-cre" appears as crew slang in unscripted and true-crime rooms. Use the full words on the site. Anyone who says "recre" will understand "recreations"; the reverse is not guaranteed.

### What has moved since the reports were written

- The August 2026 tool roundups agree on one shift: the market has moved from impressive single clips to controllable, repeatable production. The differentiators now are character consistency past 60 seconds, multi-shot continuity, native audio (soon table stakes), and machine-readable provenance, which became mandatory for EU distribution on August 2, 2026.
- Sora has lost product momentum; Veo is being distributed across Google surfaces; Seedance and Kling are gaining. ByteDance signed MPA copyright-protection agreements in August after the Seedance 2.0 controversy in February.

**What this means for you:** Do not market on tool names. They change quarterly. Market on the method, the governance, and the handoff. That is where the buyer's risk lives, and it is the part you have already built.

### Who the buyer is

The money is with people who deliver to streamers and networks: documentary and unscripted production companies, post supervisors, showrunners, and branded-content agencies. They evaluate a vendor on four questions:

1. Can you match our look and cut against our footage?
2. Will it pass legal review and the streamer's GenAI guidelines?
3. Can we audit what you did?
4. Can our team take it over?

Your case studies answer questions 3 and 4 well. The homepage answers none of them.

---

## 2. Audit by lens

Severity: **High** blocks a hire. **Medium** costs credibility. **Low** is polish.

### Lens 0: UX, design, and technical

| # | Finding | Severity | Fix |
|---|---|---|---|
| 0.1 | Three offers (AI content, websites, apps) compete in the hero and services. Focus is the first thing a professional buyer checks. | High | One offer above the fold. Move websites, apps, and fractional consulting to a secondary "Consulting" page linked from the footer, or to a separate domain. |
| 0.2 | Stats render as "0%" without JavaScript. Crawlers, AI assistants, reduced-motion users, and anyone with a blocked script read "0% of Gen Z fans prefer indie YouTube series." | High | Put the real number in the HTML. Animate up from it if you must, but never from zero. |
| 0.3 | Four autoplaying YouTube iframes and two MP4 loops on one page. Each YouTube embed loads roughly a megabyte of script before the video. Mobile users on cellular pay for all of it. | High | One hero video. Everything else gets a poster image with a play button (lite-youtube-embed or a facade). Lazy-load below the fold. Respect `prefers-reduced-motion`. |
| 0.4 | Nav "About" links to nothing. No bio, no photo, no name. | High | Build the About page (see Lens 1). |
| 0.5 | Contact form is the only contact method. No email, no calendar, no LinkedIn. The honeypot label "Don't fill this out:" appears in the extracted page text, which suggests it is hidden by CSS only. | High | See Lens 2. Hide the honeypot with `aria-hidden` and `tabindex="-1"` as well as CSS. |
| 0.6 | Work section is a feed, not a portfolio. Dick Tracy appears twice. Order is not by strength. No reel. | Medium | Curated Work index, four to six pieces, strongest first. See Lens 3. |
| 0.7 | Brand name spelled two ways: "LarryDoJo" on the homepage, "Larrydojo" on the 1863 page. | Medium | Pick one. "Larrydojo" reads cleaner and matches the LLC. |
| 0.8 | Source filenames `img-concept-megaman.jpg` and `img-char-megaman.jpg` sit under the "Robo Jr." concept. Anyone who inspects the page sees a Capcom character name on a site whose FAQ leads with IP discipline. | Medium | If Robo Jr. is original, rename the files. If it is derived from Mega Man, retire it from the portfolio. |
| 0.9 | Copy inconsistencies: player labeled "60-second sequence," case study says 40 seconds. "Anyone with a Gemini 3 Pro account" will read as dated within a quarter. | Medium | Fix the number. Replace tool-version claims with "a current image and video model." |
| 0.10 | Code-comment microcopy (`// brand bible v1.0 · locked`) and the footer line "Built fast. Hosted on Netlify. Source of truth: GitHub." speak to developers. | Low | Keep one or two as texture on the Method page. Remove from the footer and hero. Producers do not care where the site is hosted. |
| 0.11 | Alt text is good throughout. Keep it. | — | — |
| 0.12 | No structured data. | Low | Add `Person` (you), `Organization` (Larrydojo LLC), and `VideoObject` for each film. It helps Google, and it helps AI assistants describe you correctly. |

**Targets for the rebuild:** Lighthouse mobile performance above 85, Largest Contentful Paint under 2.5 seconds on 4G, zero layout shift from embeds, every stat readable with scripts off.

### Lens 1: Credibility and industry focus

**The mismatch.** The homepage says "the post-studio era," "the old digital agency model is dead," and cites GaryVee. Your target buyer works for, or delivers to, the studios. Telling them their business model is dead is a strange opening. Netflix is not post-studio; it is a studio that just bought a $600 million AI tools company.

**What you have and should surface.**

- The **authorship ledger** on the 1863 page: "What is documented. What is built." Name it, template it, and put it on every project. It is the exact artifact a Copyright Office registration and a Netflix legal review both require.
- The **Cardinal Rule** and the **five gated stages**. This is a method, not a trick. It belongs on a Method page, not inside one case study.
- **IP discipline**: public-domain sourcing, the Hawknose rename, the trademark timeline. Producers' lawyers will recognize this as their own checklist.
- **Disclosure practice**: you already disclose AI use in titles and descriptions. Say so.
- **Cost transparency**: keep the honesty, change the comparison (below).

**What is missing.**

- **You.** Name, photo, one paragraph, LinkedIn. The relevant credential for this buyer is not CRM leadership; it is fifteen years running production-grade systems and documentation inside large companies, which is why your handoffs work. Then location: Atlanta is one of the largest production hubs in the country, with an active documentary and unscripted community. Say "Atlanta, GA" on the page.
- **A reel.** Sixty to ninety seconds, 4K, cut for producers. Open on your best recreation shot. Show plate, composite, motion once. End on a card with your name and email.
- **A compliance page.** One page that maps your pipeline to the Netflix partner criteria (enterprise-secured tools, no training on inputs, disclosure, consent, no real-person likeness, no union displacement) and to what a copyright registration needs (itemized human-authored elements, disclaimed AI elements). You do not need to claim Netflix approval. You need to show you have read the document and built for it.
- **A deliverables sample.** What a producer receives: character bible, plate kit, prompt and edit log, source list, authorship ledger, provenance manifest (C2PA where the tool supports it), and the finished shots. Show the folder. Handoff-ready is your differentiator; make it visible.

**Reframe the cost.** "$0.37 per second" invites the reply "then why hire you." A producer compares against a recreation shoot day (period costumes, extras, a location, a small crew) or a VFX bid for an establishing shot. Netflix said *The American Experiment* footage came in twice as fast at half the cost, and that some shots would have been cut without it. Use that frame: "shots you would otherwise cut, delivered in days, documented for review."

**Use the vocabulary.** Recreations, reenactments, establishing shots, set extensions, crowd augmentation, previz, plates, temp versus final, delivery spec. Your copy currently says "mid-funnel," "variations," and "relevance per dollar." That is ad-tech.

**FAQ changes.**

- Update the legal answer: Supreme Court denied cert March 2, 2026. Keep the Copyright Office Part 2 citation.
- Delete "Why is the traditional agency model dead?" and the GaryVee link.
- Add: "How does this fit a streamer delivery?" Answer with the Netflix guideline structure: low-risk uses need disclosure only; final deliverables need written approval; here is what we hand you for that approval.
- Add: "What do you need from us?" Answer: reference footage or stills, the look, delivery spec (resolution, frame rate, color space, duration), the date, and who signs off.
- Keep "How is this different from AI slop?" It is good. Trim it by a third.

### Lens 2: Contact

**Current state.** One form with three fields, a promise of "a day or two," and social links. No email. No phone. No calendar. No LinkedIn. No location. A producer who wants to move today cannot.

**Fix.**

- A dedicated `/contact` page, plus a persistent "Book a call" button in the nav on every page.
- Two paths: **Book a 20-minute call** (Cal.com or Calendly) and **Send a brief** (the form).
- Show the email address in plain text. Use a real address on the domain.
- Say where you are and when you respond: "Atlanta, GA. Remote-friendly. Replies within one business day."
- Say what to send: project type, reference look, delivery spec, date, and whether an NDA is needed. Add "NDA-ready" as a plain statement.
- Form fields: name, email, company or production, project type (recreations, set extensions, previz, series, consulting), target date, optional budget range, optional reference link. Five required fields at most.
- Add LinkedIn to the footer and About page. Add IMDb the day you have a credit.
- Confirmation state should link to the reel and the Method page, not "check out the work below."

### Lens 3: Watch the key work, with deep dives

**What works.** The case studies are thorough. The 1863 method section (plate, composite, record, reconstruction, motion) is the right shape. Videos are on-site with YouTube links as a secondary path. Alt text on production stills is careful.

**What does not.**

- No reel. A producer opening the site from a text message on a phone needs the best 60 seconds in two taps.
- The homepage plays four muted loops at once. Attention has nowhere to land.
- The Dick Tracy PDF is gated by email. For lead generation that is fine; for a producer evaluating you, it is friction on the one document that proves the method.
- Projects lack a spec strip. A producer wants to see resolution, duration, turnaround, and what was real before reading a paragraph.

**Structure.**

*Work index page.* Four to six pieces, strongest first. Suggested order: 1863: A Gold Rush Story (recreation from a real primary source), Robot That Can Think (documentary reconstruction), The Dreams of Cthulhu (character consistency in a stylized register), Dick Tracy Origins (the method paper). Each card: thumbnail, one line, spec strip (`4K · 2:40 · historical recreation · 3 days · 1 primary source`), two buttons: **Watch** and **How it was made**.

*Detail page template*, in this order:

1. **Watch.** One player, poster image, click to play with sound.
2. **What was real. What was built.** The ledger, two columns, on every project.
3. **How it was made.** Plate, composite, motion, as a repeated three-frame module. Then the stages that applied.
4. **Spec and cost.** Resolution, frame rate, duration, turnaround, and the comparison (shoot day or VFX bid), not the subscription math.
5. **The handoff.** What the client receives.
6. **Next.** Link to one related project and the contact page.

*The reel.* Cut it before the redesign ships. It is the single asset that does the most work.

*Gating.* Ungate the case study summary and the first six pages. Gate the full framework with bibles and checklists behind email. That preserves the lead list and removes the friction for evaluators.

---

## 3. Redesign path

### Phase 0: This week, no redesign required

Fixes you can ship in an afternoon that remove the worst credibility leaks.

- Put the real numbers in the stats HTML.
- Update the legal FAQ to the March 2, 2026 cert denial.
- Add your name, a photo, one paragraph, Atlanta, and a LinkedIn link to the existing About anchor.
- Add a plain-text email address to the contact section.
- Hide the honeypot properly.
- Remove the duplicate Dick Tracy card.
- Rename or retire the Mega Man-named files.
- Turn off autoplay on all but the hero video.
- Pick one spelling of the brand.

### Phase 1: Weeks 1 to 3. Repositioning and rebuild

**Sitemap.**

```
/                Home (reel, three proof cards, method in five steps, built-for-review, about strip, contact)
/work            Work index
/work/[project]  Detail pages (template above)
/method          The pipeline, the Cardinal Rule, the ledger, the handoff package
/method/compliance   How the pipeline maps to streamer guidelines and copyright registration
/about           Alec Young
/contact         Book a call, send a brief
/consulting      Websites, apps, fractional work (footer link only)
```

Print Your Prompt and the 3D printing work stay on their own pages, off the main nav.

**Homepage, top to bottom.**

1. **Hero.** The reel, poster image, one line, one button. Three copy options:
   - *"AI-assisted recreations and set extensions for documentary, unscripted, and branded series. Documented for review. Built for handoff."*
   - *"The shots you would otherwise cut. Recreations, crowds, and establishing shots, delivered in days with a full authorship record."*
   - *"Historical recreation without the shoot day. Character-consistent AI video, built from primary sources, documented to pass legal review."*
2. **Three proof cards.** 1863, Robot That Can Think, Cthulhu. Spec strips. Watch and How-it-was-made.
3. **The method in five steps.** One line each. Link to /method.
4. **Built for review.** Four short statements: disclosed, documented, enterprise tools, no training on your footage. Link to /method/compliance.
5. **About strip.** Photo, name, two sentences, Atlanta, LinkedIn.
6. **Contact.** Book a call. Send a brief. Email in plain text.

**Design direction.** Keep the noir palette and the typographic confidence; it distinguishes you from the gradient-and-glow AI agency template. Lose the code-comment microcopy outside the Method page. Let stills breathe: one hero frame per section at full width beats four thumbnails.

**Technical.** Static site, one lite-embed player component, poster images generated at build, `prefers-reduced-motion` honored, structured data on every page, sitemap and Open Graph images per project. Keep Netlify and GitHub; stop advertising them.

### Phase 2: Weeks 4 to 8. Assets that close the gap

- **The reel.** 60 to 90 seconds, 4K.
- **The compliance page.** Map your pipeline to the Netflix partner guideline sections. Write it as a checklist a post supervisor can forward to legal.
- **The deliverables sample.** A downloadable folder from one project: bible, plates, ledger, log, source list, manifest.
- **One new piece aimed at the buyer.** A documentary-style recreation of a real event from archival sources, two to three minutes, with the ledger. *The American Experiment* is what Netflix pointed to; make the thing that sits next to it. Your Gabriel's Rebellion research or the Kansas ephemera archive are candidates. Public-domain comics prove consistency; an archival recreation proves you can do the job they are hiring for.
- **Update the Dick Tracy case study** to the new template and the new cost frame.

### Phase 3: Weeks 8 and on. Distribution

- LinkedIn profile rewritten to match the site. Post the ledger from each project as a carousel; producers and post supervisors live there.
- Direct outreach to Atlanta documentary and unscripted production companies, with the reel and the compliance page.
- Submit the archival recreation to the Runway AI Film Festival and one documentary festival with an AI category.
- Write one piece for a trade audience: "What a streamer's GenAI guidelines actually ask a vendor for." It is the article your buyer is searching for and nobody has written it from the vendor side.

### What to measure

- Reel plays and completion rate.
- Clicks from Work to How-it-was-made.
- Calls booked per week.
- Inbound from LinkedIn versus search.
- Time on the Method and Compliance pages. Those are the pages a serious buyer reads twice.

---

## 4. The hard decision

The websites, apps, and consulting work is real income and real skill. It also dilutes the story on the page a producer sees first. The recommendation is not to abandon it; it is to move it one click away. A site that says one thing clearly will send more of both kinds of work than a site that says three things at once.

---

## Sources checked

- Netflix Q2 2026 Shareholder Letter (July 16, 2026): s22.q4cdn.com/959853165/files/doc_financials/2026/q2/FINAL-Q2-26-Shareholder-Letter.pdf
- Variety, "About 300 Netflix Programs Used Generative AI This Year" (July 16, 2026)
- Netflix Partner Help Center, "Using Generative AI in Content Production": partnerhelp.netflixstudios.com/hc/en-us/articles/43393929218323
- SCOTUSblog, *Thaler v. Perlmutter* (No. 25-449), cert denied March 2, 2026
- Local AI Zone, "Latest AI Developments: August 2026 Update"; WaveSpeed, "AI Video Generation News: 2026"
- larrydojo.com (home, /1863-a-gold-rush-story/, /case-studies/dick-tracy-origins/), fetched August 25, 2026
