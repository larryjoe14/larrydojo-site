# Design tokens and rules

Source of truth: `src/styles/global.css` in the project.

## Palette

| Token | Hex | Use |
|---|---|---|
| ink | #121317 | Theater background: home, shows, series, the top of every episode page |
| ink-2 | #1b1d24 | Panels, inputs, thumbnails on ink |
| ink-3 | #2a2d36 | Rules and borders on ink |
| paper | #ece5d3 | The record: episode lower half, Method page |
| paper-2 | #e2dac6 | Panels on paper (the handoff folder) |
| paper-ink | #1a1814 | Text on paper; the "built" column of the ledger |
| paper-rule | #b9ae95 | Rules on paper |
| canary | #e8b93b | The only accent. Buttons, eyebrows, the play button, ledger "built" heading |
| canary-deep | #b88a1c | Canary on paper |
| fog | #a9adb8 | Secondary text on ink |

The canary comes from the Hawknose coat. Nothing else on the site is yellow.

## Type

- **Display:** Fraunces, weight 400, optical size 144 for h1, 96 for h2, 48 for h3. SOFT axis 30–40. Carries the 1860s job-printing register without costume.
- **Body:** IBM Plex Sans, 17px, line-height 1.55.
- **Utility:** IBM Plex Mono for eyebrows (12px, tracked, uppercase), spec strips (12.5px), status lines, the folder listing.
- Scale: h1 clamp(38px, 6.2vw, 76px); h2 clamp(28px, 4vw, 46px); h3 clamp(21px, 2.4vw, 27px); hero line clamp(19px, 2.1vw, 23px).

## Layout

- Max width 1180px, gutter clamp(18px, 4vw, 48px).
- Sections: padding clamp(56px, 8vw, 104px), one hairline rule between them.
- `.split` is the workhorse two-column: 1.1fr / 0.9fr, collapses at 820px.
- Cards: 16:9 thumbnails, title, spec strip, underlined link words. Posters: 2:3 with a gradient type block at the foot.
- Border radius 2px everywhere. No shadows.

## The signature

The episode page turns from screen to paper. Dark above the fold (player, prev/next, synopsis, spec). Then `.paper` wraps the ledger, the frames, the sources, the transcript, and the next card. The ledger itself is the emblem: paper column for what was documented, ink column for what was built, canary heading on the ink side.

## Rules

- No autoplay. Players are a poster frame and a canary play button; the YouTube iframe loads on click.
- One hero video per page at most.
- No code-comment microcopy (`// note`) outside the Method page.
- Eyebrows encode section type, never decoration. Numbers appear only on the five method steps and episode lists, where order carries meaning.
- Reduced motion respected: the only transitions are card-image scale on hover and smooth scroll, both disabled under `prefers-reduced-motion`.
- Focus rings: 2px canary, 3px offset, on every interactive element.
- Alt text describes the frame, not the file.
- Stats, if any return, are set in the HTML. Never animate from zero.

## Do not

- Do not reintroduce the cream-and-terracotta or black-and-acid-green template looks.
- Do not add a gradient accent, glow, or glassmorphism.
- Do not put the studio pitch on fan pages beyond the one footer line.
