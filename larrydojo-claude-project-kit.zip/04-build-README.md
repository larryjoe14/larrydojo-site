# larrydojo.com

Astro static site. One library, two doors: `/` for productions, `/shows/` for the audience. Every episode page carries the film on top and the record underneath.

## Run

```
npm install
npm run dev        # http://localhost:4321  (search index is empty in dev)
npm run build      # astro build + pagefind index → dist/
npm run preview
```

Deploy: connect the repo to Netlify. `netlify.toml` sets the build command and publish folder. Netlify Forms picks up the `brief` form on first deploy; check Site settings → Forms and add a notification email.

## Add an episode

Create `src/content/episodes/<show>/<slug>.md`. The file name is the URL: `/shows/<show>/<slug>/`.

```yaml
---
show: robo-noir              # matches a file in src/content/shows/
episode: 3
title: The Courier
synopsis: Three sentences.
youtubeId: XXXXXXXXXXX
runtime: "6:40"
released: 2026-09-18         # or 2026-09 with status: production
ledgerReal:                  # "From the source" on fiction shows
  - The 1987 setting
ledgerBuilt:                 # "Original to the show" on fiction shows
  - The courier
lesson: One or two sentences on what this episode taught.
frames: [/media/robo-noir/ep3-plate.jpg, /media/robo-noir/ep3-composite.jpg, /media/robo-noir/ep3-motion.jpg]
sources:
  - { title: Source name, url: https://... }
tags: [1987, noir]
spec: 4K · 24fps · 6:40 · 3 days
featuredInWork: true         # also appears on /work/ and the homepage proof cards
workOrder: 4                 # lower comes first
draft: false                 # true shows a "draft" badge until the copy is final
---
Transcript goes here as the body. It ships in the HTML so search can find a line of dialogue.
```

A new show is one file in `src/content/shows/`: title, status, cadence, logline, about, poster (2:3), `fiction: true` for original stories, `order` for shelf position.

Images: put them in `public/media/<show>/` and reference as `/media/<show>/file.jpg`. The current content points at images on the live site; move them into `public/media/` before the old URLs go away.

## Fill in before launch

- `src/lib/site.ts`: LinkedIn URL.
- `src/pages/index.astro`: `REEL_ID` once the reel is cut.
- `src/pages/contact.astro`: `SCHEDULER_URL` (Cal.com or Calendly embed).
- `public/media/alec.jpg` and swap the photo placeholders in `index.astro` and `about.astro`.
- Posters for Robot That Can Think and The Dreams of Cthulhu.
- `youtubeId` for Robot That Can Think, Part 1.
- Robo Noir and Cthulhu copy is placeholder; replace the synopses, ledgers, and transcripts, then remove `draft: true`.
- `public/_redirects`: confirm every old URL that has been shared.

## Where things live

```
src/content/shows/       one file per show
src/content/episodes/    one file per episode, in a folder per show
src/pages/               routes; shows/[show]/[ep].astro is the two-layer episode template
src/components/          Player (click-to-load), Ledger, Frames, EpisodeCard, PosterCard, Steps
src/lib/site.ts          site constants, the five method steps, collection helpers
src/styles/global.css    tokens and every component style
public/_redirects        old URLs → new
```

Structured data: `Organization` on the home page, `Person` on About, `TVSeries` on series pages, `TVEpisode` + `VideoObject` on episode pages. RSS at `/rss.xml` and `/shows/<show>/rss.xml`. Sitemap at `/sitemap-index.xml`.

Players load nothing from YouTube until someone presses play. Continue-watching uses `localStorage`, no account.
