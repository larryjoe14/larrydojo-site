# Copy deck

Every line of copy on the new site, by page, with the file it lives in. Edit here, then paste into the file. Lines marked *draft* are placeholders.

## Home (`src/pages/index.astro`)

**Title tag:** Larrydojo · Character-consistent AI video for documentary, unscripted, and branded series
**Meta description:** Recreations, crowds, and establishing shots you would otherwise cut, delivered in days with a full authorship record. Documented for review. Built for handoff.

**Hero headline:** Character-consistent AI video for documentary, unscripted, and branded series.
**Hero line:** Recreations, crowds, and establishing shots you would otherwise cut, delivered in days with a full authorship record. Documented for review. Built for handoff.
**Buttons:** Work with the studio · Watch the shows

Alternate headlines, if the first reads too long on mobile:
- The shots you would otherwise cut.
- Historical recreation without the shoot day.

**Proof** (eyebrow) — three cards, generated from episodes with `featuredInWork: true`, lowest `workOrder` first.

**The method** (eyebrow) — five steps, from `src/lib/site.ts`:
1. Character built once. A bible and a three-view pack, validated before anything else starts.
2. Plates built empty. Rooms and streets as reusable kits, never finished scenes.
3. Anchor, then composite. Never generate a character inside a scene. Place the anchor into the plate.
4. Last frame feeds the next. Dust, light, and prop positions carry across the cut.
5. Edit, never re-roll. A frame that is 80% right gets a natural-language fix, not a fresh draw.
Button: Read the full method

**Built for review** (eyebrow)
Headline: Disclosed. Documented. Enterprise tools. No training on your footage.
Body: Every project ships with a ledger of what was documented and what was built, a prompt and edit log, a source list, and a provenance manifest. Streamer guidelines ask for exactly this before a final deliverable is approved.
Button: How the pipeline maps to streamer guidelines

**Shows** (eyebrow)
Headline: The shows are where the method gets tested in public.
Body: Robo Noir, Robot That Can Think, The Dreams of Cthulhu, and 1863: A Gold Rush Story. Every episode carries its own ledger.
Button: All shows

**Who you would be hiring** (eyebrow)
Headline: Alec Young
Body: Fifteen years building production-grade systems and documentation inside large companies, which is why the handoffs hold. Drone and practical-effects work on the live-action side; a research habit on the other. Atlanta, GA.
Buttons: About · LinkedIn

**Contact** (eyebrow)
Headline: Two ways to start.
Buttons: Book a 20-minute call · Send a brief
Line: hello@larrydojo.com · replies within one business day · NDA-ready

## Shows hub (`src/pages/shows/index.astro`)

**Title tag:** Shows · Larrydojo
**Latest** (eyebrow) — generated from the most recent published episode. Button: Play
**Shows** (eyebrow) — posters, generated.
**Ephemera** (eyebrow) Headline: The one-minute pieces. Body: Animated postcards, cereal ads, Kansas RPPCs, and drone composites. Button: Browse by tag
**Follow** (eyebrow) — YouTube · TikTok · Instagram · RSS, all shows

## Series page (`src/pages/shows/[show]/index.astro`)

Generated from the show file. Buttons: Start here: {first episode} · How it is made
**Continue watching** (status) — shown when the browser has a last episode. Button: Resume
**Episodes** (eyebrow) — list.
**About the show** (eyebrow) — `about` from the show file, then: Made with AI. Every episode title says so, and every episode page shows what was drawn from a source and what is original. Written, directed, and produced by Alec Young.

Show files (`src/content/shows/`):

- **Robo Noir** *draft* — Ongoing · New episodes monthly. Logline: A detective robot in a 1987 city that runs on tape. Two leads, one lens, and a case that will not close. About: Original characters, original city. Built once, held in every frame. Locked character profiles and environment plates carry the same coat and the same room across every cut.
- **Robot That Can Think** — Four parts · Part 1 out now. Logline: 1958. A borrowed IBM 704 learns to tell left from right, and the Navy promises a robot that can think. About: A four-part reconstruction of the perceptron, the machine modern AI goes back to, built from period reports, photographs, and the Navy's own press language.
- **1863: A Gold Rush Story** — Short film · Complete. Logline: May 1863. A minister's week ends on a newspaper clipping: the earliest known printing of "smart aleck." The minister is invented. The clipping is real. About: A short film built from one primary source, page four of the Weekly Butte Record, Oroville, May 16, 1863, composited from the Library of Congress scan.
- **The Dreams of Cthulhu** — Ongoing · Episode 1 out now. Logline: Lovecraft's Great Old Ones fall from the stars in an inked, crosshatched comic that moves. About: "The Call of Cthulhu" (1928, public domain), adapted panel by panel. One character, built once, the same in every frame.
- **Detective Hawknose: Origins** — Origins · Method paper available. Logline: The 1931 Trueheart robbery, adapted from public-domain strips. The coat is canary. The name is ours. About: The proof of concept behind the method. Forty seconds of character-consistent video from four hero frames, with the IP timeline documented.

## Episode page (`src/pages/shows/[show]/[ep].astro`)

Fixed copy on the template:
- **The record** (eyebrow). Headline, documentary shows: What is documented. What is built. Fiction shows: From the source. Original to the show.
- Ledger column heads: What is documented / What is built, or From the source / Original to the show.
- **How it was made** (eyebrow). Frame captions: Plate · the room, built empty; Composite · the cast, placed in it; Motion · the finished shot. Button: The full method
- **Sources and deeper reading** (eyebrow)
- Transcript (summary) · Credits (summary): Written, directed, and produced by Alec Young. Made with AI; disclosed in the title. Sources listed above.
- **Up next** (eyebrow). In-production state: One message when it lands: RSS. Complete state: That is the whole film.
- Studio line: Larrydojo builds video like this for productions. Button: See the work

Episode copy lives in each episode file. 1863 is final. Hawknose is final. Robot That Can Think Part 1 is close. Robo Noir Ep. 1–2 and Cthulhu Ep. 1 are *draft*.

## Work (`src/pages/work.astro`)

**Title tag:** Work · Larrydojo
Headline: Each piece shows the shot, then the record.
Line: The shows are the studio's proving ground. Every piece below is an episode page with its ledger, its frames, and its spec.
**The method paper** (eyebrow) Headline: Detective Hawknose: Origins. Body: Forty seconds from four hero frames, the IP timeline, the cost against a traditional animation bid, and the six things that mattered. Summary open; the full framework with bibles and checklists by email. Button: Read it

## Method (`src/pages/method.astro`)

**Title tag:** Method · Larrydojo
Headline: Never generate a character inside a scene.
Line: That is the Cardinal Rule. Everything below exists to protect it. Five stages, each with a named output; no stage starts until the one before it validates.
**The ledger** (eyebrow) Headline: What is documented. What is built. Body: Every project ships with two columns. It is the same table on every episode page, and it is the record a copyright registration and a streamer's legal review both ask for.
**The handoff** (eyebrow) Headline: What you receive. Body: Built so a second team can continue the work without supervision. Folder: 01-bible, 02-plates, 03-log, 04-sources, 05-ledger.md, 06-provenance, 07-shots.
**Built for review** (eyebrow) Headline: How the pipeline maps to a streamer's GenAI guidelines.
Intro: Netflix published partner guidelines for GenAI in content production in August 2025. Other streamers ask similar questions. The left column is what a vendor is asked for. The right column is what we do and hand over.

| What the guideline asks | What we do |
|---|---|
| Disclose intended GenAI use to the production's contact. | A one-page use statement at kickoff, updated when tools or scope change. |
| Written approval before GenAI output appears in a final deliverable. | The ledger, log, and source list arrive with the first cut, so approval has something to approve. |
| Tools run in enterprise-secured environments that do not train on or retain inputs. | Enterprise-tier accounts under no-training terms. Your footage is never uploaded to a consumer tool. |
| No recreation of a real, identifiable person's likeness or voice without consent. | Invented faces by default. Any likeness requires your signed consent chain; we do not source one. |
| No replacement of union-covered work without agreement. | We build environments, crowds, and reconstructions. Performances stay with performers; the use statement says so. |
| Custom multi-tool pipelines must meet the standard at every step. | Each of the five stages names its tool, its input, and its output in the log. |

Copyright: Purely AI-generated material is not registrable in the U.S.; the Supreme Court left that standing on March 2, 2026 (Thaler v. Perlmutter). Hybrid work with meaningful human authorship is. The ledger itemizes the human-authored elements and disclaims the rest. We are not lawyers; this is the record we give yours.

## About (`src/pages/about.astro`)

**Title tag:** About · Alec Young · Larrydojo
Headline: Alec Young
Paragraph 1: I make character-consistent AI video: recreations, establishing shots, crowds, and short series built from primary sources. The method is simple to state and hard to keep. Build the character once, build the room empty, place one into the other, and let the last frame teach the next.
Paragraph 2: Before this, fifteen years running production-grade systems and documentation inside large companies. That is where the handoff discipline comes from. On the live-action side I shoot drone and practical-effects footage, and the reconstructions are built to cut against it. The shows I publish are where the method gets tested in public.
Line: Atlanta, GA · remote-friendly
Buttons: Book a call · LinkedIn · hello@larrydojo.com

## Contact (`src/pages/contact.astro`)

**Title tag:** Contact · Larrydojo
Headline: Two ways to start.
Line: Atlanta, GA · remote-friendly · replies within one business day · NDA-ready · hello@larrydojo.com
Card 1: Book a 20-minute call. Pick a time. You get a calendar invite.
Card 2: Send a brief. Fields: Name, Email, Company or production, Project type (Recreations / Set extensions / Previz / Series / Consulting), Target date, Budget range (optional: Prefer to discuss / Under $5k / $5k–$25k / $25k+), Reference link (optional), What are you making? Button: Send the brief. Note: Helpful to include: the look you want, delivery spec (resolution, frame rate, color space, duration), the date, and who signs off.
Thanks page: Your brief is in. Reply within one business day. Meanwhile: the work and the method.

## Consulting (`src/pages/consulting.astro`)

Headline: Websites, apps, and fractional work.
Line: AI strategy and proofs of concept, custom plumbing between the tools you already pay for, and monthly advisory with a builder in the room. Scoped to fit. This page lives one click off the main site on purpose.
Button: Inquire

## Footer (`src/layouts/Base.astro`)

Atlanta, GA · hello@larrydojo.com · YouTube · TikTok · Instagram · LinkedIn · RSS · Consulting
© 2026 Larrydojo LLC. Shows disclose AI use in every title. Source newspaper pages and archival photographs are public domain; reconstructions © Larrydojo LLC.

## Off-site copy to match

**YouTube description, first line:** Watch in order at larrydojo.com/shows/{show}/ · Made with AI.
**TikTok bio link:** larrydojo.com/shows/
**Episode title pattern:** {Show} Ep. {n}: {Title} (AI)
