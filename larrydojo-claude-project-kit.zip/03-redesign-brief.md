# Larrydojo.com Redesign Brief

**For:** Alec Young, Larrydojo LLC
**Date:** August 25, 2026
**Companion to:** larrydojo-site-audit-2026-08.md

---

## The recommendation in one paragraph

Build one site with two front doors. The homepage is for the producer: reel, proof, method, contact. The Shows hub is for the fan: every series, every episode, in order, with a next button. Both doors open onto the same library, because every episode page carries two layers: the film on top, "how it was made" underneath. A fan who scrolls past the player finds the ledger. A producer who reads the ledger finds the next episode. You maintain one set of pages, and each page does two jobs.

**Positioning line:** *Larrydojo makes character-consistent AI video for documentary, unscripted, and branded series, and publishes its own shows the same way.*

The shows are the portfolio. Saying so out loud is the whole trick.

---

## Site architecture

```
/                     Home (buyer-first, with a Shows strip)
/shows                Shows hub (fan-first)
/shows/[show]         Series page: poster, logline, episode list in order, start here
/shows/[show]/[ep]    Episode page: player, next/previous, ledger, how it was made
/work                 Curated index for buyers (links into episode pages and case studies)
/method               The pipeline, the Cardinal Rule, the ledger, the handoff package
/method/compliance    How the pipeline maps to streamer guidelines and copyright registration
/about                Alec Young
/contact              Book a call, send a brief
/consulting           Websites, apps, fractional work (footer only)
/search               Site search (Pagefind, static)
```

**Navigation:** Shows · Work · Method · About · Contact · [Book a call]

Two nouns tell the visitor which door they are at. "Shows" is for watching. "Work" is for hiring. Method sits between them because it belongs to both.

---

## Page briefs

Each brief states the audience, the one action the page exists to produce, what it must contain, and a wireframe.

### Home

**Audience:** A producer, post supervisor, or showrunner who received the link by text or email.
**One action:** Play the reel, then book a call.
**Secondary:** Send a fan to the Shows hub.

**Must contain:** the reel; one positioning line; three proof cards; the method in five lines; the review statement; your name, photo, and city; a Shows strip; contact.

**Copy direction.** Every line answers one of the four buyer questions: can you match our look, will it pass review, can we audit it, can we take it over. Nothing about agencies, algorithms, or funnels.

```
+--------------------------------------------------------------+
| LARRYDOJO        Shows  Work  Method  About  Contact  [Call] |
+--------------------------------------------------------------+
|                                                              |
|   [ REEL: poster frame, play button, 60-90s, 4K ]            |
|                                                              |
|   Character-consistent AI video for documentary,             |
|   unscripted, and branded series.                            |
|   Documented for review. Built for handoff.                  |
|                                                              |
|   [ Work with the studio ]   [ Watch the shows ]             |
+--------------------------------------------------------------+
| PROOF                                                        |
| [1863: A Gold Rush]  [Robot That Can Think]  [Cthulhu]       |
|  4K · 2:40 · recre  4K · 4 parts · doc      4K · series      |
|  Watch / How made    Watch / How made        Watch / How made|
+--------------------------------------------------------------+
| THE METHOD                                                   |
| 1 Character built once   2 Plates built empty                |
| 3 Anchor, then composite 4 Last frame feeds the next         |
| 5 Edit, never re-roll                          -> /method    |
+--------------------------------------------------------------+
| BUILT FOR REVIEW                                             |
| Disclosed. Documented. Enterprise tools. No training on      |
| your footage.                        -> /method/compliance   |
+--------------------------------------------------------------+
| SHOWS   Robo Noir · Robot That Can Think · Dreams of Cthulhu |
|         [latest episode card]              -> /shows         |
+--------------------------------------------------------------+
| [photo] Alec Young. Fifteen years building production-grade  |
|         systems for enterprises. Atlanta, GA.   LinkedIn     |
+--------------------------------------------------------------+
| CONTACT   [Book a 20-minute call]   [Send a brief]           |
|           hello@larrydojo.com · replies within one business  |
|           day · NDA-ready                                    |
+--------------------------------------------------------------+
```

### Shows hub (`/shows`)

**Audience:** A fan arriving from YouTube, TikTok, a search, or a share.
**One action:** Press play on the right episode.

**Must contain:** every show as a poster card with logline, episode count, and status (ongoing, complete, short film); a "Latest" module at the top; a "Start here" pick for newcomers; subscribe links (YouTube, TikTok, RSS, email).

**Order:** Latest release first, then shows by most recent episode. Complete shows and short films below. Nothing on this page sells services. The footer carries the studio link.

```
+--------------------------------------------------------------+
| LATEST   [Robo Noir · Ep. 3 · "title" · 6:12 · Aug 20]       |
|          [ Play ]                                            |
+--------------------------------------------------------------+
| SHOWS                                                        |
| [poster]           [poster]              [poster]            |
| Robo Noir          Robot That Can Think  Dreams of Cthulhu   |
| Ongoing · 3 eps    Complete · 4 parts    Ongoing · 1 ep      |
| New to it? Ep. 1   Start at Part 1       Start: The Arrival  |
|                                                              |
| [poster]           [poster]                                  |
| 1863: A Gold Rush  Detective Hawknose                        |
| Short film · 2:40  Origins · 1 ep                            |
+--------------------------------------------------------------+
| EPHEMERA   Animated postcards, cereal ads, RPPCs, drone      |
|            composites. The one-minute pieces.  -> collection |
+--------------------------------------------------------------+
| FOLLOW   YouTube · TikTok · Instagram · RSS · Email          |
+--------------------------------------------------------------+
```

### Series page (`/shows/[show]`)

**Audience:** A fan deciding whether to commit, or returning for the next episode.
**One action:** Play the next unwatched episode.

**Must contain:** poster and title; logline (two sentences); status and cadence ("new episodes monthly"); episode list in release order, numbered, each with thumbnail, title, runtime, date, one-line synopsis; a "Start here" button on the pilot; season grouping when a show passes eight episodes; a short "About the show" with the source material and the AI disclosure; credits; "Made with" link to the show's method page.

**Continue watching.** Store the last episode viewed in the browser and surface it at the top on return. A static site can do this with a few lines of script and no account.

### Episode page (`/shows/[show]/[ep]`)

This is the most important template on the site. It is the page fans share and the page producers study.

**Audience:** Both.
**One action, fan:** Watch, then press Next.
**One action, producer:** Read the ledger, then click "Work with the studio."

**Layout, top to bottom.**

1. **Player.** Poster frame, click to play with sound. Title, show name, episode number, runtime, release date. Previous and Next buttons directly under the player. Nothing else above the fold.
2. **Synopsis.** Three sentences. Then chapter markers if the episode runs past three minutes.
3. **What is real. What is built.** The two-column ledger from the 1863 page, on every episode. For a fiction series like Robo Noir, the columns become "From the source" and "Original to the show."
4. **How it was made.** Plate, composite, motion, as three frames. Two or three sentences on what this episode taught you. Link to the full method.
5. **Sources and deeper reading.** Primary sources with links, as on 1863.
6. **Transcript.** Collapsed by default, full text in the HTML. This is what search engines and AI assistants read; it is also what makes the episode findable by a line of dialogue.
7. **Next episode card.** Large. Followed by "All episodes" and the subscribe row.
8. **Studio footer.** One line: "Larrydojo builds video like this for productions. See the work." That is the only sales copy on the page.

**URL and title conventions.** URLs read `/shows/robo-noir/ep-2-title-slug/`. Page titles read `Robo Noir Ep. 2: Title | Larrydojo`. YouTube titles and descriptions match the page, disclose AI use, and link back to the episode page as the canonical home.

### Work (`/work`)

**Audience:** Producer.
**One action:** Open a project and read how it was made.

**Must contain:** four to six curated pieces, strongest first, each with a spec strip and two buttons (Watch, How it was made). The Watch button opens the episode page. The How-it-was-made button opens the same page scrolled to the ledger. Below the grid: a one-line explanation that the shows are the studio's proving ground, and a link to the Dick Tracy case study as the method paper.

Work is a curated view of the same library. It has no content of its own. That is what keeps the two doors in sync.

### Method (`/method`) and Compliance (`/method/compliance`)

**Audience:** Producer, and the post supervisor or lawyer the producer forwards it to.
**One action:** Forward it.

**Method must contain:** the Cardinal Rule; the five gated stages, each with its named output; the ledger, explained as a deliverable; the handoff package, shown as a folder listing (bible, plate kit, prompt and edit log, source list, ledger, provenance manifest, finished shots); a note on disclosure practice; tool policy stated without version numbers ("current image, video, and reasoning models, run under enterprise terms that do not train on inputs").

**Compliance must contain:** a table. Left column, the criteria a streamer's GenAI guidelines ask a vendor to meet (disclosure to the production, written approval for final deliverables, enterprise-secured tools, no training or retention of production data, no real-person likeness without consent, no displacement of union-covered work). Right column, what you do and what you hand over. Below it, the copyright registration note: human-authored elements itemized, AI elements disclaimed, the ledger as the record. End with "we are not lawyers; this is the record we give yours."

### About (`/about`)

**Audience:** Producer checking who they would hire.
**One action:** Connect on LinkedIn or book a call.

**Must contain:** photo; name; two paragraphs. First: what you make and how (the method, in plain words). Second: where it comes from (fifteen years running production-grade systems and documentation inside large companies, which is why the handoffs hold; drone and practical-effects work; the research habit). Then: Atlanta, GA; remote-friendly; LinkedIn; email; the shows you publish, with a line that they are where the method gets tested in public.

### Contact (`/contact`)

**Audience:** Producer ready to move.
**One action:** Book or send.

**Must contain:** two paths side by side, Book a 20-minute call (embedded scheduler) and Send a brief (form: name, email, company or production, project type, target date, optional budget range, optional reference link). Plain-text email. "Atlanta, GA. Remote-friendly. Replies within one business day. NDA-ready." Under the form: "What to send: reference footage or stills, the look you want, delivery spec, the date, who signs off." Confirmation page links to the reel and the Method page.

---

## How fans find episodes

Fans rarely arrive at a homepage. They arrive at an episode from a platform, a search, or a share. The repository has to work from any entry point.

**On the platforms.** Every YouTube description opens with the episode page link and the words "Watch in order at larrydojo.com/shows/robo-noir." Every TikTok bio link points to `/shows`, and every vertical cut ends with the episode number. Playlists on YouTube mirror the series pages one to one.

**In search.** Each episode page carries `TVEpisode` and `VideoObject` structured data with series, episode number, duration, upload date, and thumbnail; each series page carries `TVSeries`. The transcript in the HTML gives search engines the dialogue. Titles follow one pattern. An RSS feed per show and one for all shows lets podcast apps and readers subscribe.

**On the site.** A search box on every page (Pagefind indexes the static HTML, including transcripts, so a fan can find an episode by a line they remember). Previous and Next under every player. "Continue watching" on the series page. A "Latest" module on the hub and on the homepage. Tags on episodes (era, source, technique) with tag pages, so the 1863 film and the Kansas postcards connect through "Gold Rush" or "1860s."

**In email.** One list, one message per release, the episode page as the link. The Dick Tracy PDF gate already collects addresses; merge the lists.

---

## Content model

Each episode is one file with front matter. The site generator builds every view from it.

```yaml
show: robo-noir
season: 1
episode: 2
title: "Episode title"
slug: ep-2-episode-title
logline: "One sentence."
synopsis: "Three sentences."
youtube_id: x0AGG2U6eMs
poster: /media/robo-noir/ep-2-poster.jpg
runtime: "6:12"
released: 2026-08-20
status: published
ledger:
  real: ["The 1931 strips", "The yellow coat"]
  built: ["The minister", "Every street image"]
method_frames: [plate.jpg, composite.jpg, motion.mp4]
lesson: "Two sentences on what this episode taught."
sources:
  - title: "Weekly Butte Record, May 16, 1863"
    url: https://chroniclingamerica.loc.gov/...
tags: [1860s, gold-rush, recreation]
transcript: ep-2.vtt
spec: { resolution: 4K, fps: 24, turnaround_days: 3 }
featured_in_work: true
work_order: 2
```

`featured_in_work` and `work_order` are the only fields the buyer view needs. Flip a flag and an episode appears on `/work`.

**Stack.** Astro on Netlify with GitHub as the source, which is what you run now. Content collections for shows and episodes. `lite-youtube-embed` for every player. Pagefind for search. Image optimization at build. One layout for episodes, one for series, one for the studio pages.

---

## Design direction

Keep the noir palette and the typographic confidence. Add one thing: **posters.** Every show gets a poster in the same format, and every episode gets a frame chosen as a poster, not a thumbnail. Posters are how audiences recognize a show and how producers judge a look at a glance. The Shows hub should look like a shelf.

Drop the code-comment microcopy everywhere except the Method page. Let one full-width still lead each section. Autoplay nothing.

---

## Build order

1. **Content first.** Write the front matter for every existing episode and short. This is a weekend and it is the foundation.
2. **Episode and series templates.** Ship `/shows` with the current library before touching the homepage. Fans get value immediately; the studio pages then point at something that already works.
3. **Method and Compliance.** Text pages, fast to build, highest value per hour for the buyer.
4. **Home, Work, About, Contact.** Home last, because it summarizes everything else.
5. **The reel.** Cut it in parallel; drop it in when the homepage ships.
6. **Redirects.** Old case-study and film URLs redirect to their new episode pages so nothing shared before the redesign breaks.

Four to six weeks at a steady pace. The audit's Phase 0 fixes still go out this week on the current site.
